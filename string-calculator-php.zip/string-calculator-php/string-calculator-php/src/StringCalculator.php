<?php

namespace Deg540\StringCalculatorPHP;

class StringCalculator
{
    // TODO: String StringCalculator Kata

    function add($string):int{
        $lista=explode(",",$string);
        $suma=0;
        for($i=0;$i<=$lista.ob_get_length();$i++){
            $suma=$suma+(int)($lista[$i]);
        }
        return $suma;
    }

}